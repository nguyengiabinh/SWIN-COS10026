http://127.0.0.1:5500/WEEK1/lab1/lab1.html
https://mercury.swin.edu.au/cos10026/s104219428/LAB01/myhtml.html